# Adapter
## Instaleren
Download de code
```bash
git clone https://github.com/tim83/adapter
```
Installeer de code
```bash
cd adapter
bash install.sh
```
Verwijder de code
```bash
cd ..
rm -r adapter
```
